This folder contains data sets and stata code to replicate the analysis of
"The Church, Intensive Kinship, Global Psychological Variation".

The data sets and files are organized according to the level of analysis. 
For each level of analysis there is a folder with the stata do-file and the associated data set.

For the analyses stata version 15.1 was used. 
